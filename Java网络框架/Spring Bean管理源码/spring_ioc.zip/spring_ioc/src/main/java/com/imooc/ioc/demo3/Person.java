package com.imooc.ioc.demo3;

/**
 * Created by jt on 2017/10/9.
 */
public class Person {

}
