package com.imooc.ioc.demo3;

public interface UserDao {
    public void findAll();

    public void save();

    public void update();

    public void delete();
}
