package com.imooc.ioc.demo1;

/**
 * Created by jt on 2017/10/8.
 */
public interface UserService {
    public void sayHello();
}
