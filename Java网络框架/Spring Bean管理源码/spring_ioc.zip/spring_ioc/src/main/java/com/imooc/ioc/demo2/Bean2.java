package com.imooc.ioc.demo2;

/**
 * Bean的实例化三种方式：静态工厂实例化方式
 */
public class Bean2 {

}
