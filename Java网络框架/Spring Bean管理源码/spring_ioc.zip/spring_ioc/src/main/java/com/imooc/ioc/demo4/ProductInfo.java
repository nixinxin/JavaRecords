package com.imooc.ioc.demo4;

public class ProductInfo {

    public Double calculatePrice(){
        return Math.random() * 199;
    }
}
