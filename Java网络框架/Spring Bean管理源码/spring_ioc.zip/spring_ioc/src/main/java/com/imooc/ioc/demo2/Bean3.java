package com.imooc.ioc.demo2;

/**
 * Bean的实例化三种方式：实例工厂实例化
 */
public class Bean3 {

}
