package com.imooc.demo3;

public class ProductDao {
    public void save(){
        System.out.println("ProductDao的save方法执行了...");
    }
}
