package com.imooc.demo3;

public class CategoryDao {
    public void save(){
        System.out.println("CategoryDao中的save方法执行了...");
    }
}
